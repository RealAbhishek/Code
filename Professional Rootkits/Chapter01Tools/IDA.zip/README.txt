
-----------------------------------------------------------------------------
                   Contents
-----------------------------------------------------------------------------

    1. What is IDA?

    2. Installation
        
    3. License agreement

    4. Other versions

    5. Contact Information

-----------------------------------------------------------------------------
               1. What is IDA?
-----------------------------------------------------------------------------

IDA is an Advanced Interactive Disassembler that allows you to
disassemble 80x86/Pentium III, Z80 and I51 binaries. Today, it is widely used
by the security industry in the analysis of hostile code and validation
of COTS. This versions also offers FLIRT our Fast Library Identification and
Recognition Technology that identifies the standard library calls of
many 80x86 compilers.

Supported processors:           Intel 8080, 8085, Z80, HD 64180
                                Intel 8086/87
                                Intel 80286/287 real & protected
                                Intel 80386/387 real & protected
                                Intel 80486/487 real & protected
                                Intel Pentium   real & protected
                                Intel Pentium II and III extensions
                                Intel 8051 series
                                Zilog Z80 and derivatives


-----------------------------------------------------------------------------
               2. How to Install IDA Pro Freeware
-----------------------------------------------------------------------------

The idafree.zip file should be uncompressed in its own directory with
the subdirectory structure saved in the archive. This can be achieved by
using 

        pkunzip -d idafree.zip

in the directory of your choice.




-----------------------------------------------------------------------------
                3. License agreement
-----------------------------------------------------------------------------

        Copyright (c) 2000 by Datarescue SA/NV; All rights reserved.

Freeware Version License 

     1. This version of IDA is released as freeware for all uses.
They are encouraged to purchase the more advanced IDA Pro 4.x GUI version but
are under no obligation to do so.

     2. IDA is provided AS IS without any  warranty, expressed or implied,
including but not limited to fitness for a particular use. The  user  is
responsible for the results of correct or incorrect usage of this software.
Datarescue disclaims all warranties as to this software, whether express
or implied, including without  limitation  any  implied warranties  of
merchantability, fitness for a particular  purpose, functionality or data
integrity or protection.

* All product names mentioned in  IDA  are  trademarks  or  registered
  trademarks of their respective holders.

-----------------------------------------------------------------------------
             4. Other versions
-----------------------------------------------------------------------------

     This is a freeware product and it requires no registration.

The freeware version is an older version of Professional Interactive
Disassembler IDA PRO. IDA PRO is the most sophisticated and powerful
disassembler available today. Evaluation of the latest versions can be
downloaded from the www.datarescue.com web site.

-----------------------------------------------------------------------------
            4. Sites with the new versions
-----------------------------------------------------------------------------

  The future freeware versions may appear at

      http://www.simtel.com/pub/simtelnet/msdos/disasm


  Professional version of IDA is at http://www.idapro.com

-----------------------------------------------------------------------------
            5. Contact Information
-----------------------------------------------------------------------------
 
  We are always glad to receive suggestions for improvements or
comments. Our contact information is

        DataRescue sa/nv
        45 quai de la Derivation
        4020 Li�ge - Belgium
        Tel : +32-4-3446510
        Fax : +32-4-3446514
        e-mail : idapro@datarescue.com
        web : http://www.datarescue.com


NOTE:
-----
IDA incorporates compression code by the Info-ZIP group.
There are no extra charges or costs due to the use of this code,
and the original compression sources are freely available from
CompuServe in the IBMPRO forum and by anonymous ftp from the
Internet site ftp.uu.net:/pub/archiving/zip.  We will also, upon
request, mail you the full sources on a 3.5" MSDOS-format disk-
ette for the cost of mailing.


-----------------------------------------------------------------------------
                END OF README
-----------------------------------------------------------------------------
